'use client'
import * as React from 'react'
import { toast } from 'sonner'
import {
  Warehouse, ClipboardList, ShoppingBag, PackageMinus, Plus, CheckCircle2, Send, X,
  Search, PackagePlus, Info, Wand2,
} from 'lucide-react'
import { api } from '@/lib/api'
import { toFaDigits } from '@/lib/jalali'
import { hasRole, type PUser, type ProductT } from '@/lib/types'
import {
  Card, SectionHeader, Badge, StockBadge, stockDot, Field, inputCls, PrimaryButton, GoldButton,
  GhostButton, DangerButton, EmptyState, Modal, Tabs, Avatar, TimeAgo, ProductImage, Spinner,
} from './kit'
import { WarehouseRequestsSkeleton, CustomerAsksSkeleton, LowStockListSkeleton } from './Skeletons'
import { LowStockDraftModal } from './LowStockDraft'

/* ---------- local types ---------- */
type WRequest = {
  id: number
  productId: number
  qty: number
  requestedById: number
  status: string // OPEN | PREPARED | RECEIVED | CANCELLED
  note: string | null
  createdAt: string
  preparedAt: string | null
  product?: { id: number; name: string; sellPrice: number; stock: number } | null
  requestedBy?: { id: number; name: string } | null
}
type CRequest = {
  id: number
  name: string
  barcode: string | null
  count: number
  note: string | null
  requestedById: number
  createdAt: string
  updatedAt: string
  requestedBy?: { id: number; name: string } | null
}

const AVATAR_COLORS = ['#3E6B4A', '#B8860B', '#8B5CF6', '#0F766E', '#BE185D', '#C2410C', '#4D7C0F', '#6D28D9']
const colorFor = (id: number) => AVATAR_COLORS[Math.abs(id) % AVATAR_COLORS.length]

const WR_STATUS: Record<string, { label: string; cls: string }> = {
  OPEN: { label: 'در انتظار آماده‌سازی', cls: 'border-amber-200 bg-amber-50 text-amber-800' },
  PREPARED: { label: 'آماده شد', cls: 'border-violet-200 bg-violet-50 text-violet-800' },
  RECEIVED: { label: 'دریافت شد', cls: 'border-emerald-200 bg-emerald-50 text-emerald-800' },
  CANCELLED: { label: 'لغو شد', cls: 'border-stone-200 bg-stone-100 text-stone-600' },
}

export default function WarehouseSection({ user }: { user: PUser }) {
  const isSupervisor = hasRole(user, 'INVENTORY_SUPERVISOR')
  const isMerch = hasRole(user, 'MERCHANDISER')
  const canCreateOrders =
    hasRole(user, 'GENERAL_MANAGER') || hasRole(user, 'PRODUCT_MANAGER') ||
    hasRole(user, 'OPERATION_MANAGER') || hasRole(user, 'IT_ADMIN')

  const [tab, setTab] = React.useState('requests')
  const [loading, setLoading] = React.useState(true)
  const [draftOpen, setDraftOpen] = React.useState(false)

  /* ---------- data ---------- */
  const [requests, setRequests] = React.useState<WRequest[]>([])
  const [asks, setAsks] = React.useState<CRequest[]>([])
  const [lowProducts, setLowProducts] = React.useState<ProductT[]>([])

  const loadRequests = React.useCallback(async () => {
    try {
      const res = await api.get<{ requests: WRequest[] }>('/api/warehouse-requests')
      setRequests(res.requests ?? [])
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در دریافت درخواست‌های انبار')
    }
  }, [])

  const loadAsks = React.useCallback(async () => {
    try {
      const res = await api.get<{ requests: CRequest[] }>('/api/customer-requests')
      setAsks(res.requests ?? [])
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در دریافت درخواست مشتریان')
    }
  }, [])

  const loadLow = React.useCallback(async () => {
    try {
      const res = await api.get<{ products: ProductT[] }>('/api/products?low=1&limit=500')
      setLowProducts(res.products ?? [])
      setQtyReq(Object.fromEntries((res.products ?? []).map((p) => [p.id, String(Math.max(1, Math.ceil(p.minStock)))])))
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در دریافت کمبود موجودی')
    }
  }, [])

  React.useEffect(() => {
    void (async () => {
      setLoading(true)
      await Promise.all([loadRequests(), loadAsks(), loadLow()])
      setLoading(false)
    })()
  }, [loadRequests, loadAsks, loadLow])

  /* ---------- request actions ---------- */
  const [busyId, setBusyId] = React.useState<number | null>(null)

  const actRequest = async (r: WRequest, action: 'prepare' | 'receive' | 'cancel') => {
    setBusyId(r.id)
    try {
      await api.patch('/api/warehouse-requests', { id: r.id, action, userId: user.id })
      if (action === 'prepare') toast.success('درخواست آماده شد — به درخواست‌دهنده اطلاع داده شد')
      if (action === 'receive') toast.success('دریافت ثبت شد و موجودی کالا بروزرسانی شد')
      if (action === 'cancel') toast.info('درخواست لغو شد')
      void loadRequests()
      if (action === 'receive') void loadLow()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در ثبت عملیات')
    } finally {
      setBusyId(null)
    }
  }

  /* ---------- new warehouse request (modal) ---------- */
  const [newOpen, setNewOpen] = React.useState(false)
  const [allProducts, setAllProducts] = React.useState<ProductT[]>([])
  const [prodQ, setProdQ] = React.useState('')
  const [picked, setPicked] = React.useState<ProductT | null>(null)
  const [newQty, setNewQty] = React.useState('1')
  const [newNote, setNewNote] = React.useState('')
  const [creating, setCreating] = React.useState(false)

  const openNew = async () => {
    setPicked(null); setProdQ(''); setNewQty('1'); setNewNote('')
    setNewOpen(true)
    if (allProducts.length === 0) {
      try {
        const res = await api.get<{ products: ProductT[] }>('/api/products?limit=500')
        setAllProducts(res.products ?? [])
      } catch {
        toast.error('خطا در دریافت فهرست کالاها')
      }
    }
  }

  const submitRequest = async () => {
    if (!picked) { toast.error('کالا را انتخاب کنید'); return }
    const qty = Number(newQty)
    if (!Number.isFinite(qty) || qty <= 0) { toast.error('تعداد باید بزرگ‌تر از صفر باشد'); return }
    setCreating(true)
    try {
      await api.post('/api/warehouse-requests', {
        productId: picked.id, qty, requestedById: user.id, note: newNote.trim() || null,
      })
      toast.success('درخواست انبار ثبت شد — انباردار مطلع شد')
      setNewOpen(false)
      void loadRequests()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در ثبت درخواست')
    } finally {
      setCreating(false)
    }
  }

  const filteredPick = prodQ.trim()
    ? allProducts.filter((p) =>
        p.name.toLowerCase().includes(prodQ.trim().toLowerCase()) ||
        (p.nameFa ?? '').includes(prodQ.trim()) ||
        (p.barcode ?? '').includes(prodQ.trim())
      ).slice(0, 50)
    : allProducts.slice(0, 50)

  /* ---------- customer asks ---------- */
  const [askOpen, setAskOpen] = React.useState(false)
  const [askName, setAskName] = React.useState('')
  const [askNote, setAskNote] = React.useState('')
  const [savingAsk, setSavingAsk] = React.useState(false)
  const [plusOneId, setPlusOneId] = React.useState<number | null>(null)

  const submitAsk = async () => {
    if (!askName.trim()) { toast.error('نام کالا را بنویسید'); return }
    setSavingAsk(true)
    try {
      const res = await api.post<{ duplicate: boolean }>('/api/customer-requests', {
        name: askName.trim(), note: askNote.trim() || null, requestedById: user.id,
      })
      toast.success(res.duplicate ? 'این کالا قبلاً ثبت شده بود — شمارش +۱ شد' : 'درخواست مشتری ثبت شد (+۱ امتیاز)')
      setAskOpen(false); setAskName(''); setAskNote('')
      void loadAsks()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در ثبت درخواست')
    } finally {
      setSavingAsk(false)
    }
  }

  const plusOne = async (r: CRequest) => {
    setPlusOneId(r.id)
    try {
      const res = await api.post<{ duplicate: boolean }>('/api/customer-requests', { name: r.name, requestedById: user.id })
      toast.success(res.duplicate ? `«${r.name}» — شمارش بروزرسانی شد` : 'ثبت شد')
      void loadAsks()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در ثبت')
    } finally {
      setPlusOneId(null)
    }
  }

  /* ---------- lowstock quick request ---------- */
  const [qtyReq, setQtyReq] = React.useState<Record<number, string>>({})
  const [lowBusy, setLowBusy] = React.useState<number | null>(null)

  const quickRequest = async (p: ProductT) => {
    const qty = Number(qtyReq[p.id]) || Math.max(1, Math.ceil(p.minStock))
    if (qty <= 0) { toast.error('تعداد نامعتبر است'); return }
    setLowBusy(p.id)
    try {
      await api.post('/api/warehouse-requests', { productId: p.id, qty, requestedById: user.id, note: 'درخواست سریع از بخش کمبود موجودی' })
      toast.success(`درخواست ${p.name} از انبار ثبت شد`)
      void loadRequests()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در ثبت درخواست')
    } finally {
      setLowBusy(null)
    }
  }

  /* ---------- render ---------- */
  return (
    <div>
      <SectionHeader
        title="انبار | Warehouse"
        subtitle="درخواست برداشت از انبار، درخواست مشتریان و کمبود موجودی"
        icon={<Warehouse className="h-5 w-5" />}
        actions={
          <PrimaryButton onClick={() => void openNew()} className="min-h-[44px]">
            <Plus className="h-4 w-4" /> درخواست جدید از انبار
          </PrimaryButton>
        }
      />

      <Tabs
        active={tab}
        onChange={setTab}
        tabs={[
          { key: 'requests', label: 'درخواست‌های انبار', icon: <ClipboardList className="h-4 w-4" /> },
          { key: 'customer-asks', label: 'درخواست مشتریان', icon: <ShoppingBag className="h-4 w-4" /> },
          { key: 'lowstock', label: 'کمبود موجودی', icon: <PackageMinus className="h-4 w-4" /> },
        ]}
      />

      {loading ? (
        tab === 'requests' ? (
          <WarehouseRequestsSkeleton />
        ) : tab === 'customer-asks' ? (
          <CustomerAsksSkeleton />
        ) : (
          <LowStockListSkeleton />
        )
      ) : null}

      {!loading && tab === 'requests' && (
        <div className="max-h-[68vh] space-y-3 overflow-y-auto pz-scroll pl-1">
          {requests.length === 0 ? (
            <EmptyState icon={<ClipboardList className="h-10 w-10" />} title="درخواستی ثبت نشده" hint="با دکمه «درخواست جدید از انبار» اولین درخواست را ثبت کنید." />
          ) : (
            requests.map((r) => {
              const st = WR_STATUS[r.status] ?? { label: r.status, cls: 'border-stone-200 bg-stone-100 text-stone-600' }
              const canPrepare = isSupervisor && r.status === 'OPEN'
              const canReceive = isMerch && r.status === 'PREPARED'
              const canCancel = r.requestedById === user.id && r.status === 'OPEN'
              return (
                <Card key={r.id} className="p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-bold text-[#253A2A]" title={r.product?.name ?? ''}>
                        {r.product?.name ?? `کالا #${toFaDigits(r.productId)}`}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-[#6B7A66]">
                        <Badge className="border-[#E4DCC8] bg-white text-[#4A5A44]">
                          تعداد: <b className="text-sm">{toFaDigits(Math.floor(r.qty))}</b>
                        </Badge>
                        <TimeAgo iso={r.createdAt} />
                      </div>
                    </div>
                    <Badge className={st.cls}>{st.label}</Badge>
                  </div>
                  {r.note && <p className="mt-2 rounded-lg bg-[#FBF9F3] px-3 py-1.5 text-xs leading-5 text-[#6B5B2A]">{r.note}</p>}
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#EFEAD8] pt-3">
                    <div className="flex items-center gap-2">
                      <Avatar name={r.requestedBy?.name ?? '؟'} color={colorFor(r.requestedById)} size={28} />
                      <span className="text-xs font-medium text-[#4A5A44]">{r.requestedBy?.name ?? 'کاربر'}</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {canPrepare && (
                        <PrimaryButton onClick={() => void actRequest(r, 'prepare')} disabled={busyId === r.id} className="min-h-[44px]">
                          {busyId === r.id ? <Spinner /> : <CheckCircle2 className="h-4 w-4" />} آماده شد
                        </PrimaryButton>
                      )}
                      {canReceive && (
                        <PrimaryButton onClick={() => void actRequest(r, 'receive')} disabled={busyId === r.id} className="min-h-[44px]">
                          {busyId === r.id ? <Spinner /> : <Send className="h-4 w-4" />} دریافت کردم
                        </PrimaryButton>
                      )}
                      {canCancel && (
                        <DangerButton onClick={() => void actRequest(r, 'cancel')} disabled={busyId === r.id} className="min-h-[44px]">
                          <X className="h-4 w-4" /> لغو
                        </DangerButton>
                      )}
                    </div>
                  </div>
                </Card>
              )
            })
          )}
        </div>
      )}

      {!loading && tab === 'customer-asks' && (
        <div className="space-y-3">
          <Card className="flex items-start gap-3 border-[#C8D8C0] bg-gradient-to-l from-[#F3F7EF] to-[#FBF9F3] p-4">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-[#3E6B4A]" />
            <p className="text-sm leading-6 text-[#33402F]">
              هر محصولی که مشتری خواست و نداشتیم اینجا ثبت می‌شود تا مدیریت سفارش بدهد.
            </p>
          </Card>

          <div className="flex justify-end">
            <GoldButton onClick={() => { setAskName(''); setAskNote(''); setAskOpen(true) }} className="min-h-[44px]">
              <Plus className="h-4 w-4" /> ثبت درخواست جدید مشتری
            </GoldButton>
          </div>

          {asks.length === 0 ? (
            <EmptyState icon={<ShoppingBag className="h-10 w-10" />} title="هنوز درخواستی از مشتری‌ها ثبت نشده" hint="وقتی مشتری کالایی خواست که نداشتیم، همین‌جا ثبتش کنید." />
          ) : (
            <div className="max-h-[62vh] overflow-y-auto pz-scroll pl-1">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {asks.map((r) => (
                  <Card key={r.id} className="flex flex-col p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-base font-bold leading-7 text-[#253A2A]">{r.name}</div>
                      <Badge className={r.count >= 3 ? 'border-rose-200 bg-rose-50 text-rose-700' : 'border-[#E4DCC8] bg-white text-[#4A5A44]'}>
                        ×{toFaDigits(r.count)} بار پرسیده شده
                      </Badge>
                    </div>
                    {r.note && <p className="mt-1.5 text-xs leading-5 text-[#6B7A66]">{r.note}</p>}
                    <div className="mt-2 flex items-center gap-2">
                      <Avatar name={r.requestedBy?.name ?? '؟'} color={colorFor(r.requestedById)} size={24} />
                      <span className="text-xs text-[#4A5A44]">{r.requestedBy?.name ?? 'کاربر'}</span>
                      <span className="text-[10px] text-[#B8B29A]">·</span>
                      <TimeAgo iso={r.updatedAt} />
                    </div>
                    <div className="mt-3 border-t border-[#EFEAD8] pt-3">
                      <PrimaryButton onClick={() => void plusOne(r)} disabled={plusOneId === r.id} className="w-full min-h-[44px]">
                        {plusOneId === r.id ? <Spinner /> : <Plus className="h-4 w-4" />} مشتری دیگری هم پرسید +۱
                      </PrimaryButton>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {!loading && tab === 'lowstock' && (
        <div className="max-h-[68vh] space-y-3 overflow-y-auto pz-scroll pl-1">
          {lowProducts.length > 0 && canCreateOrders && (
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-[#EAD9A8] bg-gradient-to-l from-[#FBF6E8] to-[#FDFBF3] px-4 py-3">
              <div className="text-sm font-bold leading-6 text-[#6B5B2A]">
                {toFaDigits(lowProducts.length)} کالا زیر حداقل موجودی — می‌توانید برای همه تأمین‌کنندگان یک‌جا پیش‌نویس سفارش بسازید
              </div>
              <GoldButton className="min-h-[44px]" onClick={() => setDraftOpen(true)}>
                <Wand2 className="h-4 w-4" /> سفارش خودکار از کمبودها
              </GoldButton>
            </div>
          )}
          {lowProducts.length === 0 ? (
            <EmptyState icon={<PackageMinus className="h-10 w-10" />} title="کمبود موجودی نداریم 🎉" hint="همه کالاها بالای حداقل موجودی هستند." />
          ) : (
            lowProducts.map((p) => (
              <Card key={p.id} className="flex flex-wrap items-center gap-3 p-3.5">
                <ProductImage src={p.imageUrl} name={p.name} size={48} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-bold text-[#253A2A]" title={p.name}>{p.name}</div>
                  {p.nameFa && <div className="truncate text-xs text-[#6B7A66]">{p.nameFa}</div>}
                  <div className="mt-1 flex flex-wrap items-center gap-2">
                    <StockBadge stock={p.stock} minStock={p.minStock} />
                    <span className={`text-xs font-bold tabular-nums ${stockDot(p.stock, p.minStock)}`}>
                      {toFaDigits(Math.floor(p.stock))} از حداقل {toFaDigits(Math.floor(p.minStock))}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    value={qtyReq[p.id] ?? ''}
                    onChange={(e) => setQtyReq((m) => ({ ...m, [p.id]: e.target.value }))}
                    className={`${inputCls} w-20 min-h-[44px] px-2 text-center tabular-nums`}
                    aria-label={`تعداد درخواست برای ${p.name}`}
                    title="تعداد درخواست"
                  />
                  <GhostButton onClick={() => void quickRequest(p)} disabled={lowBusy === p.id} className="min-h-[44px] shrink-0">
                    {lowBusy === p.id ? <Spinner /> : <PackagePlus className="h-4 w-4" />} درخواست از انبار
                  </GhostButton>
                </div>
              </Card>
            ))
          )}
        </div>
      )}

      {/* ---------- new warehouse request modal ---------- */}
      <Modal open={newOpen} onClose={() => setNewOpen(false)} title="درخواست جدید از انبار">
        <div className="space-y-3">
          <Field label="کالا" required>
            {picked ? (
              <div className="flex items-center justify-between gap-2 rounded-xl border border-[#5F8F55] bg-[#F3F7EF] px-3 py-2.5 text-sm">
                <span className="font-semibold text-[#3E6B4A]">{picked.name}{picked.nameFa ? ` — ${picked.nameFa}` : ''}</span>
                <button type="button" onClick={() => setPicked(null)} className="rounded-full p-1 text-[#6B7A66] hover:bg-white" aria-label="حذف انتخاب">
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <>
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#A8A28C]" />
                  <input
                    value={prodQ}
                    onChange={(e) => setProdQ(e.target.value)}
                    className={`${inputCls} min-h-[44px] pr-9`}
                    placeholder="جستجوی کالا…"
                    autoFocus
                  />
                </div>
                <div className="mt-2 max-h-48 divide-y divide-[#EFEAD8] overflow-y-auto rounded-xl border border-[#E4DCC8] bg-white pz-scroll">
                  {filteredPick.length === 0 && <div className="p-3 text-xs text-[#8A9884]">کالایی پیدا نشد</div>}
                  {filteredPick.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => { setPicked(p); setProdQ('') }}
                      className="flex w-full items-center justify-between gap-2 px-3 py-2.5 text-right text-sm transition hover:bg-[#F3F7EF]"
                    >
                      <span className="min-w-0 truncate font-medium text-[#33402F]">{p.name}</span>
                      <span className={`shrink-0 text-xs tabular-nums ${stockDot(p.stock, p.minStock)}`}>موجودی {toFaDigits(Math.floor(p.stock))}</span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </Field>
          <Field label="تعداد" required>
            <input type="number" min={1} value={newQty} onChange={(e) => setNewQty(e.target.value)} className={inputCls} dir="ltr" />
          </Field>
          <Field label="یادداشت">
            <input value={newNote} onChange={(e) => setNewNote(e.target.value)} className={inputCls} placeholder="مثلاً برای قفسه ۳ لبنیات" />
          </Field>
          <div className="flex justify-end gap-2 border-t border-[#EFEAD8] pt-3">
            <GhostButton onClick={() => setNewOpen(false)} className="min-h-[44px]">انصراف</GhostButton>
            <PrimaryButton onClick={() => void submitRequest()} disabled={creating} className="min-h-[44px]">
              {creating ? <Spinner /> : <PackagePlus className="h-4 w-4" />} ثبت درخواست
            </PrimaryButton>
          </div>
        </div>
      </Modal>

      {/* ---------- low-stock auto-draft modal ---------- */}
      <LowStockDraftModal user={user} open={draftOpen} onClose={() => setDraftOpen(false)} />

      {/* ---------- new customer ask modal ---------- */}
      <Modal open={askOpen} onClose={() => setAskOpen(false)} title="درخواست مشتری">
        <div className="space-y-3">
          <Field label="نام کالایی که مشتری خواست" required>
            <input value={askName} onChange={(e) => setAskName(e.target.value)} className={inputCls} placeholder="مثلاً شیر بادام‌زمینی" autoFocus />
          </Field>
          <Field label="یادداشت">
            <input value={askNote} onChange={(e) => setAskNote(e.target.value)} className={inputCls} placeholder="مثلاً دو بار پرسیدند؛ برند دلخواه…" />
          </Field>
          <div className="flex justify-end gap-2 border-t border-[#EFEAD8] pt-3">
            <GhostButton onClick={() => setAskOpen(false)} className="min-h-[44px]">انصراف</GhostButton>
            <GoldButton onClick={() => void submitAsk()} disabled={savingAsk} className="min-h-[44px]">
              {savingAsk ? <Spinner /> : <Plus className="h-4 w-4" />} ثبت
            </GoldButton>
          </div>
        </div>
      </Modal>
    </div>
  )
}
